from .randombot import RandomBot

__all__ = ["RandomBot"]
